const ts=require('typescript'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'lingobridge/src');
const routes={
'pages/public/LandingPage.jsx':'/', 'pages/student/LanguageSelectPage.jsx':'/languages',
'pages/auth/LoginPage.jsx':'/login', 'pages/auth/RegisterPage.jsx':'/register',
'pages/auth/ForgotPasswordPage.jsx':'/forgot-password',
'pages/student/StudentDashboard.jsx':'/dashboard','pages/student/CourseViewPage.jsx':'/course/:code',
'pages/student/LessonDetailPage.jsx':'/lesson/:id','pages/student/QuizPage.jsx':'/lesson/:id/quiz',
'pages/student/FlashcardsPage.jsx':'/flashcards','pages/student/ProfilePage.jsx':'/profile',
'pages/admin/AdminDashboard.jsx':'/admin','pages/admin/ManageLanguagesPage.jsx':'/admin/languages',
'pages/admin/ManageLessonsPage.jsx':'/admin/lessons','pages/admin/ManageVocabularyPage.jsx':'/admin/vocabulary',
'pages/admin/ManageQuizzesPage.jsx':'/admin/quizzes','pages/admin/ManageVideosPage.jsx':'/admin/videos',
'pages/admin/AudioManagementPage.jsx':'/admin/audio','pages/admin/StudentOverviewPage.jsx':'/admin/students',
'pages/admin/CurriculumManagerPage.jsx':'/admin/curriculum',
'pages/public/NotFoundPage.jsx':'*'};
const interactive=[];const pages=[];let bad=[];
function walkDir(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walkDir(path.join(d,e.name)):/\.(jsx|js)$/.test(e.name)?[path.join(d,e.name)]:[])}
for(const f of walkDir(root)){
 const rel=path.relative(root,f).replaceAll('\\','/'),src=fs.readFileSync(f,'utf8');
 const tree=ts.createSourceFile(f,src,ts.ScriptTarget.Latest,true,f.endsWith('.jsx')?ts.ScriptKind.JSX:ts.ScriptKind.JS);
 if(tree.parseDiagnostics.length)bad.push({file:rel,errors:tree.parseDiagnostics.map(x=>ts.flattenDiagnosticMessageText(x.messageText,' '))});
 let elems=[];function visit(n){
  if(ts.isJsxElement(n)||ts.isJsxSelfClosingElement(n)){
   const opening=ts.isJsxElement(n)?n.openingElement:n;
   const name=opening.tagName.getText(tree);
   if(['button','Button','Link','a','input','select','textarea','form'].includes(name)){
    const attrs={};for(const a of opening.attributes.properties){if(!ts.isJsxAttribute(a))continue;
      attrs[a.name.getText(tree)]=a.initializer?.getText(tree).slice(0,130)??'true';}
    const pos=tree.getLineAndCharacterOfPosition(opening.getStart(tree));
    const body=ts.isJsxElement(n)?n.children.map(x=>x.getText(tree)).join(' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,115):'';
    elems.push({file:rel,route:routes[rel]||'(shared component)',line:pos.line+1,kind:name,label:body||attrs['aria-label']||attrs.placeholder||'(dynamic/icon/control)',handler:attrs.onClick||attrs.onSubmit||attrs.type||attrs.to||attrs.href||'', disabled:attrs.disabled||'',onChange:attrs.onChange||''});
   }
  }
  ts.forEachChild(n,visit);
 }
 visit(tree);interactive.push(...elems);
 if(routes[rel])pages.push({route:routes[rel],file:rel,controls:elems.length,links:elems.filter(i=>i.kind==='Link'||i.kind==='a').length,buttons:elems.filter(i=>i.kind==='button'||i.kind==='Button').length,inputs:elems.filter(i=>['input','select','textarea'].includes(i.kind)).length,forms:elems.filter(i=>i.kind==='form').length});
}
const inventory={total_source_files:walkDir(root).length, syntax_errors:bad, total_controls:interactive.length, app_pages:pages, controls:interactive};
fs.writeFileSync(path.resolve(__dirname,'frontend_control_inventory.json'),JSON.stringify(inventory,null,2));
const csv=x=>'"'+String(x).replaceAll('"','""').replaceAll('\n',' ')+'"';
fs.writeFileSync(path.resolve(__dirname,'frontend_controls.csv'),['route,file,line,kind,label,handler,disabled,onChange',...interactive.map(i=>Object.values(i).map(csv).join(','))].join('\n'));
console.log(JSON.stringify({total_source_files:inventory.total_source_files,total_controls:inventory.total_controls,app_pages:pages.length,syntax_errors:bad.length,pages},null,2));
