"""Isolated real FastAPI walkthrough; all created records live ONLY in the temporary SQLite QA DB."""
import os, sys, json, io, math, wave, uuid, collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'lingobridge'
DB=ROOT/'disposable_manual_test.db'
os.environ['DATABASE_URL']='sqlite:///'+str(DB)
os.environ['JWT_SECRET']='qa_disposable_0123456789_very_long_key_0123456789'
os.environ['ENVIRONMENT']='test'
os.environ['MEDIA_DIR']=str(ROOT/'test_media')
(BASE/'backend').resolve()
sys.path.insert(0,str(BASE/'backend'))
from fastapi.testclient import TestClient
from sqlalchemy import select,func
from app.db import Base, engine, SessionLocal
from app import models as m, local_tts
from app.main import app
from app.security import hash_password
from app.audio_validation import inspect_audio
REPORT=[]
def record(area,name,ok,detail='',kind='API integration'):
    status='PASS' if ok else 'FAIL'
    REPORT.append(dict(area=area,name=name,status=status,detail=str(detail)[:240],kind=kind))
    if not ok: print('FAIL', area, name, str(detail)[:220], flush=True)
def check(area,name,condition,detail=''):
    record(area,name,bool(condition),detail)
def req(c,area,name,method,url,expected=200,**kwargs):
    try:
        r=c.request(method,url,**kwargs)
        ok=(r.status_code in (expected if isinstance(expected,(tuple,list,set)) else (expected,)))
        record(area,name,ok,f'{method} {url}, got {r.status_code}, expected {expected}; {r.text[:140] if not ok else ""}')
        return r
    except Exception as e:
        record(area,name,False,'EXCEPTION '+repr(e));return None
def data(resp):
    try:return resp.json() if resp else None
    except:return None
def csrf(client,response):
    if response and response.status_code<400:
        client.headers['X-CSRF-Token']=response.json()['csrf']
def example_answer(q,correct=True):
    k=q.question_type
    if k=='mcq':
        opts=list(d.scalars(select(m.Option).where(m.Option.question_id==q.id)).all())
        opt=next((o for o in opts if bool(o.is_correct)==correct),opts[0])
        return {'question_id':q.id,'option_id':opt.id}
    if k=='matching':
        pairs=(q.meta or {}).get('pairs',[])
        return {'question_id':q.id,'text':'|'.join(f'{a}:{b}' for a,b in pairs) if correct else 'incorrect'}
    return {'question_id':q.id,'text':q.answer_text if correct else 'this is certainly not the correct answer'}
def qs(lesson):
    with SessionLocal() as d:
        return list(d.scalars(select(m.Question).where(m.Question.lesson_id==lesson).order_by(m.Question.id)).all())

new_database=not DB.exists()
Base.metadata.create_all(engine)
from app.seed import seed
if new_database:seed()
# repeat seed is avoided so QA edits are not repaired unexpectedly
with SessionLocal() as d:
    languages=d.scalars(select(m.Language)).all()
    courses=d.scalars(select(m.Course)).all()
    lessons=d.scalars(select(m.Lesson)).all()
    vocabulary=d.scalars(select(m.Vocabulary)).all()
    questions=d.scalars(select(m.Question)).all()
    options=d.scalars(select(m.Option)).all()
    counts={k:len(v) for k,v in [('languages',languages),('courses',courses),('lessons',lessons),('vocabulary',vocabulary),('questions',questions),('options',options)]}
    check('Catalogue','10 supported languages',len(languages)==10,counts)
    check('Catalogue','6 CEFR bands for 10 languages',len(courses)==60,counts)
    check('Catalogue','All lessons belong to courses',all(d.get(m.Module,l.module_id) for l in lessons))
    check('Catalogue','All vocabulary refers to lessons',all(d.get(m.Lesson,v.lesson_id) for v in vocabulary))
    check('Catalogue','All question references valid lesson',all(d.get(m.Lesson,q.lesson_id) for q in questions))
    check('Catalogue','Nonempty language courses',all(any(l.module_id in {md.id for md in d.scalars(select(m.Module).where(m.Module.course_id==c.id))} for l in lessons) for c in courses))
    check('MCQ','Every MCQ has exactly one correct answer and 2-8 options',all(sum(o.is_correct for o in options if o.question_id==q.id)==1 and 2<=sum(o.question_id==q.id for o in options)<=8 for q in questions if q.question_type=='mcq'))
    check('MCQ','Every fill blank and arrangement has answer',all(q.answer_text and q.answer_text.strip() for q in questions if q.question_type in ('fill_blank','arrangement')))
    check('MCQ','Matching exercise has pair metadata',all(len((q.meta or {}).get('pairs',[]))>=2 for q in questions if q.question_type=='matching'))
    types=dict(collections.Counter(q.question_type for q in questions))
    codes={x.code:x.id for x in languages}
    for code in sorted(codes):
        current=[l for l in lessons if l.language_id==codes[code]]
        check('Language '+code,'Has authored lesson content',bool(current),f'{len(current)} lessons')
        check('Language '+code,'Has vocabulary content',any(v.lesson_id in {l.id for l in current} for v in vocabulary),f'{len(current)} lessons')
        check('Language '+code,'Has quiz content',any(q.lesson_id in {l.id for l in current} for q in questions),f'{len(current)} lessons')
    # don't retain objects outside session

with TestClient(app,raise_server_exceptions=False) as anon, TestClient(app,raise_server_exceptions=False) as student, TestClient(app,raise_server_exceptions=False) as other, TestClient(app,raise_server_exceptions=False) as admin:
    # guest
    req(anon,'Public','Health endpoint','GET','/api/health')
    r=req(anon,'Public','Public language catalogue','GET','/api/languages')
    check('Public','Exactly 10 languages returned',len(data(r) or [])==10)
    req(anon,'Public','CEFR level catalogue','GET','/api/levels')
    req(anon,'Public','Published courses catalogue','GET','/api/courses')
    req(anon,'Public','Published lessons catalogue','GET','/api/lessons')
    req(anon,'Public','Unknown language gives 404','GET','/api/languages/wut',404)
    req(anon,'Auth','Guest cannot view profile','GET','/api/auth/me',401)
    req(anon,'Student RBAC','Guest cannot see lesson','GET','/api/lessons/les-en-1',401)
    req(anon,'Admin RBAC','Guest cannot see admin stats','GET','/api/admin/stats',401)
    req(anon,'Audio','Guest cannot generate speech','POST','/api/pronunciation',401,json={'lang':'en','text':'Hello'})
    req(anon,'Auth','Weak password rejected','POST','/api/auth/register',422,json={'full_name':'QA Student','email':'weak-qa@example.com','password':'Password1234'})
    req(anon,'Auth','Common password rejected','POST','/api/auth/register',422,json={'full_name':'QA Student','email':'common-qa@example.com','password':'Password123!'})
    sr=req(student,'Auth','Registration','POST','/api/auth/register',201,json={'full_name':'QA Student','email':'manual-student@example.com','password':'ValidStudent123!'})
    csrf(student,sr)
    check('Auth','Student password hash not leaked',bool(data(sr)) and 'password_hash' not in str(data(sr)), '')
    req(student,'Auth','Duplicate email blocked','POST','/api/auth/register',409,json={'full_name':'QA Duplicate','email':'manual-student@example.com','password':'ValidStudent123!'})
    req(student,'Auth','CSRF protection blocks missing token','PATCH','/api/profile',403,json={'full_name':'Bad CSRF'},headers={'X-CSRF-Token':''})
    req(student,'Auth','Current user endpoint','GET','/api/auth/me')
    req(student,'Auth','Wrong login rejected','POST','/api/auth/login',401,json={'email':'manual-student@example.com','password':'BadPassword123!'})
    sl=req(student,'Auth','Valid login succeeds','POST','/api/auth/login',200,json={'email':'manual-student@example.com','password':'ValidStudent123!'})
    csrf(student,sl)
    req(student,'Student RBAC','Student blocked from admin stats','GET','/api/admin/stats',403)
    req(student,'Student RBAC','Student blocked from edit admin content','POST','/api/admin/manage/lessons',403,json={'title':'bad'})
    req(student,'Student RBAC','Student blocked from audio inventory','GET','/api/pronunciation/status',403)
    req(student,'Student','Unenrolled English lesson denied','GET','/api/lessons/les-en-1',403)
    req(student,'Student','Unenrolled English quiz denied','POST','/api/lessons/les-en-1/quiz-session',403)
    req(student,'Profile','Save profile/preferences','PATCH','/api/profile',200,json={'full_name':'QA Learner Updated','native_language_id':'lang-hi','target_language_id':'lang-en','daily_goal':20})
    req(student,'Profile','Invalid daily learning goal blocked','PATCH','/api/profile',422,json={'daily_goal':300})
    req(student,'Profile','Unknown language rejected','PATCH','/api/profile',400,json={'target_language_id':'lang-wut'})
    req(student,'Profile','Read activity card','GET','/api/activity')
    req(student,'Student','Empty bookmarks list','GET','/api/bookmarks')
    req(student,'Student','No enrollment recommendations','GET','/api/recommendations')
    # Test language and level course cards with actual HTTP and service data
    for code in sorted(codes):
        lang_id=codes[code]
        lr=req(anon,'Language '+code,'Language detail card','GET','/api/languages/'+code)
        check('Language '+code,'Locale set',bool(data(lr)) and bool(data(lr).get('tts_locale')),data(lr).get('tts_locale') if data(lr) else '')
        for lvl in ('a1','a2','b1','b2','c1','c2'):
            cid=f'course-{code}-{lvl}'
            mr=req(anon,'Course '+code,'Course modules '+lvl.upper(),'GET',f'/api/courses/{cid}/modules')
            check('Course '+code,f'Course {lvl.upper()} has lesson cards',bool(data(mr)) and bool(data(mr)[0].get('lessons')))
        enr=req(student,'Student','Enroll in '+code+' A1','POST',f'/api/courses/course-{code}-a1/enroll')
        check('Student','Course '+code+' A1 reports enrolled',bool(data(enr)) and data(enr).get('enrolled') is True)
        req(student,'Student','Duplicate enrollment '+code+' idempotent','POST',f'/api/courses/course-{code}-a1/enroll')
        # choose A1 lesson with 4 question types where possible
        with SessionLocal() as d:
            mod_id=f'module-{code}-a1'
            candidates=list(d.scalars(select(m.Lesson).where(m.Lesson.module_id==mod_id,m.Lesson.is_published==True).order_by(m.Lesson.lesson_order,m.Lesson.id)).all())
            chosen=next((l for l in candidates if d.scalar(select(func.count()).select_from(m.Question).where(m.Question.lesson_id==l.id))>=4), candidates[0])
            chosen_id=chosen.id
        lr=req(student,'Student','Open '+code+' A1 lesson','GET',f'/api/lessons/{chosen_id}')
        check('Student','Quiz answer keys hidden '+code, bool(data(lr)) and all('is_correct' not in op and 'answer_text' not in q for q in data(lr).get('quiz_questions',[]) for op in q.get('options',[])))
        req(student,'Student','Start '+code+' A1 lesson','POST',f'/api/lessons/{chosen_id}/start')
        ticket=req(student,'MCQ','Open secure quiz '+code,'POST',f'/api/lessons/{chosen_id}/quiz-session')
        with SessionLocal() as d:
            qq=list(d.scalars(select(m.Question).where(m.Question.lesson_id==chosen_id).order_by(m.Question.id)).all())
            answer_payload=[]
            for q in qq:
                if q.question_type=='mcq':
                    opts=list(d.scalars(select(m.Option).where(m.Option.question_id==q.id)).all());answer_payload.append({'question_id':q.id,'option_id':next(o.id for o in opts if o.is_correct)})
                elif q.question_type=='matching':
                    answer_payload.append({'question_id':q.id,'text':'|'.join(f'{a}:{b}' for a,b in (q.meta or {}).get('pairs',[]))})
                else: answer_payload.append({'question_id':q.id,'text':q.answer_text})
        if data(ticket) and data(ticket).get('attempt_token'):
            token=data(ticket)['attempt_token']
            req(student,'MCQ','Missing quiz ticket rejected '+code,'POST',f'/api/lessons/{chosen_id}/submit',403,json={'answers':answer_payload})
            req(student,'MCQ','Incomplete quiz submission blocked '+code,'POST',f'/api/lessons/{chosen_id}/submit',400,json={'answers':answer_payload[:-1],'attempt_token':token})
            result=req(student,'MCQ','Full quiz pass '+code,'POST',f'/api/lessons/{chosen_id}/submit',200,json={'answers':answer_payload,'attempt_token':token})
            check('MCQ','Correct score + progress '+code, bool(data(result)) and data(result).get('passed')==True and data(result).get('score')==len(qq),str(data(result))[:90])
            req(student,'MCQ','Replay token denied '+code,'POST',f'/api/lessons/{chosen_id}/submit',403,json={'answers':answer_payload,'attempt_token':token})
        req(student,'Student','Bookmark lesson '+code,'POST',f'/api/bookmarks/{chosen_id}')
        with SessionLocal() as d:
            word=d.scalar(select(m.Vocabulary).where(m.Vocabulary.lesson_id==chosen_id))
            wid=word.id
        fc=req(student,'Flashcards','Mark card known '+code,'PUT',f'/api/flashcards/{wid}',200,json={'state':'known'})
        check('Flashcards','Card schedules review '+code,bool(data(fc)) and data(fc).get('repetitions',0)>=1)
    req(student,'Student','View enrolled course cards','GET','/api/courses/enrolled/me')
    progress=req(student,'Student','View completed lesson progress','GET','/api/progress')
    check('Student','10+ quiz attempts persisted',len((data(progress) or {}).get('quiz_attempts',[]))>=10)
    req(student,'Student','Review learning recommendations','GET','/api/recommendations')
    req(student,'Flashcards','Load all review cards','GET','/api/flashcards')
    req(student,'Flashcards','Revise card again','PUT',f'/api/flashcards/{wid}',200,json={'state':'revise'})
    req(student,'Flashcards','Invalid review status rejected','PUT',f'/api/flashcards/{wid}',400,json={'state':'mastered'})
    bookmarks=req(student,'Student','Saved lesson cards list','GET','/api/bookmarks')
    check('Student','10 bookmarks persisted',len(data(bookmarks) or [])>=10)
    req(student,'Student','Remove saved lesson','DELETE',f'/api/bookmarks/{chosen_id}')
    req(student,'Student','Record 10 minutes of study','POST','/api/activity',200,json={'minutes':10})
    req(student,'Student','Record out-of-bounds study rejected','POST','/api/activity',400,json={'minutes':9999})
    req(student,'Student','Load learning activity and XP','GET','/api/activity')
    req(student,'Student','Reload complete student profile','GET','/api/auth/me')
    req(other,'Auth','Second student registration','POST','/api/auth/register',201,json={'full_name':'QA Other','email':'manual-other@example.com','password':'ValidOther123!'})
    req(other,'Student','Other user cannot access student private lesson','GET','/api/lessons/les-en-1',403)
    req(other,'Student RBAC','Other user cannot see all students','GET','/api/admin/students',403)
    # Admin login isolated identity
    with SessionLocal.begin() as d:
        d.add(m.User(id='manual-qa-admin',email='manual-admin@example.com',full_name='Manual QA Admin',password_hash=hash_password('ManualAdmin123!'),role='admin',is_active=True))
    ar=req(admin,'Admin Auth','Administrator login','POST','/api/auth/login',200,json={'email':'manual-admin@example.com','password':'ManualAdmin123!'})
    csrf(admin,ar)
    req(admin,'Admin','Dashboard KPI cards','GET','/api/admin/stats')
    allstudents=req(admin,'Admin','Students and quiz progress cards','GET','/api/admin/students')
    check('Admin','Students do not leak password hashes',bool(data(allstudents)) and all('password_hash' not in x for x in data(allstudents)))
    for tab in ['languages','levels','courses','modules','lessons','vocabulary','questions','options','achievements']:
        req(admin,'Admin','Admin management table: '+tab,'GET',f'/api/admin/manage/{tab}')
    req(admin,'Admin','Reject undefined management tab','GET','/api/admin/manage/other',404)
    req(admin,'Admin','Admin update student name','PATCH','/api/admin/students/'+data(sr)['user']['id'],200,json={'full_name':'Edited by QA Admin'})
    req(admin,'Admin','Reject privileged student role edit','PATCH','/api/admin/students/'+data(sr)['user']['id'],400,json={'role':'admin'})
    req(admin,'Admin','Temporarily deactivate student','PATCH','/api/admin/students/'+data(sr)['user']['id'],200,json={'is_active':False})
    req(student,'Auth','Deactivated login access denied','GET','/api/auth/me',401)
    req(admin,'Admin','Reactivate student','PATCH','/api/admin/students/'+data(sr)['user']['id'],200,json={'is_active':True})
    req(student,'Auth','Reactivated student access restored','GET','/api/auth/me')
    req(admin,'Admin RBAC','Admin cannot deactivate own account','PATCH','/api/admin/students/manual-qa-admin',400,json={'is_active':False})
    #  CRUD for draft content, no learner history
    newlesson=req(admin,'Admin CRUD','Create lesson','POST','/api/admin/manage/lessons',201,json={'module_id':'module-en-a1','language_id':'lang-en','level_id':'lvl-a1','title':'QA disposable lesson','description':'QA generated only','content':'Demo','grammar_notes':'This is only disposable testing','lesson_order':997,'duration_minutes':7,'is_published':True})
    lid=(data(newlesson) or {}).get('id')
    if lid:
        req(admin,'Admin CRUD','Edit lesson title','PATCH',f'/api/admin/manage/lessons/{lid}',200,json={'title':'QA edited lesson'})
        v=req(admin,'Admin CRUD','Add vocabulary card','POST',f'/api/admin/lessons/{lid}/vocabulary',201,json={'word':'temporary','translation':'अस्थायी','example_sentence':'temporary QA'})
        vid=(data(v) or {}).get('id')
        if vid:
            req(admin,'Admin CRUD','Edit vocabulary card','PATCH',f'/api/admin/manage/vocabulary/{vid}',200,json={'translation':'temporary QA translation'})
        req(admin,'Admin CRUD','Auto-move lesson to matching language course','PATCH',f'/api/admin/manage/lessons/{lid}',200,json={'language_id':'lang-hi'})
        badq=req(admin,'Admin MCQ','Reject multiple correct options','POST',f'/api/admin/lessons/{lid}/questions',400,json={'question_text':'Bad MCQ?','options':[{'option_text':'One','is_correct':True},{'option_text':'Two','is_correct':True}]})
        req(admin,'Admin MCQ','Reject zero correct options','POST',f'/api/admin/lessons/{lid}/questions',400,json={'question_text':'Bad MCQ?','options':[{'option_text':'One','is_correct':False},{'option_text':'Two','is_correct':False}]})
        q=req(admin,'Admin MCQ','Create 2-option single-answer MCQ','POST',f'/api/admin/lessons/{lid}/questions',201,json={'question_text':'QA MCQ?','options':[{'option_text':'Yes','is_correct':True},{'option_text':'No','is_correct':False}]})
        qid=(data(q) or {}).get('id')
        if qid:
            opts=(data(q) or {}).get('options',[])
            correct=next(o for o in opts if o['is_correct']);wrong=next(o for o in opts if not o['is_correct'])
            req(admin,'Admin MCQ','Block second correct via option PATCH','PATCH',f'/api/admin/manage/options/{wrong["id"]}',409,json={'is_correct':True})
            req(admin,'Admin MCQ','Block removing only correct answer','PATCH',f'/api/admin/manage/options/{correct["id"]}',409,json={'is_correct':False})
            req(admin,'Admin MCQ','Block deleting only correct answer','DELETE',f'/api/admin/manage/options/{correct["id"]}',409)
            req(admin,'Admin MCQ','Reject invalid complete MCQ editor','PUT',f'/api/admin/questions/{qid}',400,json={'question_text':'invalid','options':[{'option_text':'Yes','is_correct':True},{'option_text':'No','is_correct':True}]})
            req(admin,'Admin MCQ','Edit complete MCQ valid','PUT',f'/api/admin/questions/{qid}',200,json={'question_text':'Updated QA MCQ?'})
            # purposeful invariant test: an MCQ must retain 2 options
            req(admin,'Admin MCQ','Delete last wrong option must be blocked (2-option minimum)','DELETE',f'/api/admin/manage/options/{wrong["id"]}',409)
        req(admin,'Admin CRUD','Protect previously reviewed vocab','DELETE',f'/api/admin/manage/vocabulary/{wid}',409)
        # all new draft content is deletable; question deleted first to avoid FK issues
        if qid:
            req(admin,'Admin CRUD','Remove QA MCQ question','DELETE',f'/api/admin/manage/questions/{qid}',200)
        if vid:
            req(admin,'Admin CRUD','Delete QA vocabulary','DELETE',f'/api/admin/manage/vocabulary/{vid}',200)
        req(admin,'Admin CRUD','Delete QA lesson','DELETE',f'/api/admin/manage/lessons/{lid}',200)
    req(admin,'Admin Data Safety','Block lesson deletion with progress history','DELETE','/api/admin/manage/lessons/les-en-1',409)
    req(admin,'Admin Data Safety','Block course deletion with enrollments','DELETE','/api/admin/manage/courses/course-en-a1',409)
    req(admin,'Admin Data Safety','Archive language retaining users','DELETE','/api/admin/manage/languages/lang-en',200)
    with SessionLocal() as d:
        language=d.get(m.Language,'lang-en')
        enroll_count=d.scalar(select(func.count()).select_from(m.Enrollment).where(m.Enrollment.language_id=='lang-en'))
        check('Admin Data Safety','Archived language preserves enrollments',language and not language.is_active and enroll_count>0)
    # restore temporary staging language state, never production
    req(admin,'Admin Data Safety','Reactivate archived language','PATCH','/api/admin/manage/languages/lang-en',200,json={'is_active':True})
    # audio status, invalid source, missing engines, valid WAV, missing/fake media
    status=req(admin,'Audio','Admin multilingual voice inventory','GET','/api/pronunciation/status')
    engines=(data(status) or {}).get('engines',{})
    check('Audio','All 10 language statuses enumerated',len(engines)==10)
    for code,info in engines.items():
        check('Audio',f'{code} locale and engine truthful',info.get('verified_spoken_quality','')=='NOT TESTED on this server',str(info))
        if not info.get('piper_configured') and not info.get('espeak_installed_voice'):
            req(student,'Audio',f'{code} speech missing-voice message','POST','/api/pronunciation',503,json={'lang':code,'text':{'hi':'नमस्ते','mr':'नमस्कार','ta':'வணக்கம்'}.get(code,'Hello')})
    req(student,'Audio','Invalid TTS language blocked','POST','/api/pronunciation',422,json={'lang':'xx','text':'Hello'})
    req(student,'Audio','Empty pronunciation blocked','POST','/api/pronunciation',422,json={'lang':'en','text':''})
    req(student,'Audio','Oversized text blocked','POST','/api/pronunciation',422,json={'lang':'en','text':'a'*350})
    req(student,'Audio','Control-char TTS text blocked','POST','/api/pronunciation',422,json={'lang':'en','text':'hi\x00bye'})
    req(student,'Audio','Student cannot upload voice recording','POST','/api/admin/audio',403,files={'file':('evil.wav',b'evil','audio/wav')})
    req(admin,'Audio','Reject disguised audio upload','POST','/api/admin/audio',400,files={'file':('fake.wav',b'X'*500,'audio/wav')})
    req(admin,'Audio','Reject tiny audio upload','POST','/api/admin/audio',400,files={'file':('fake.mp3',b'ID3'+b'\0'*8,'audio/mpeg')})
    stream=io.BytesIO()
    with wave.open(stream,'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(16000)
        f.writeframes(b'\0\0'*32000)
    audio=req(admin,'Audio','Upload decodable WAV file','POST','/api/admin/audio',201,files={'file':('test.wav',stream.getvalue(),'audio/wav')})
    if data(audio) and data(audio).get('audio_url'):
        req(anon,'Audio','Serve uploaded decodable recording','GET',data(audio)['audio_url'])
    req(anon,'Audio','Reject 35-byte ID3 placeholder','GET','/api/media/114a97af-fe35-41f5-89e8-52b1673b67cc.mp3',404)
    req(admin,'Auth','Admin logout','POST','/api/auth/logout')
    req(admin,'Admin RBAC','Logged-out admin access denied','GET','/api/admin/stats',401)
    req(student,'Auth','Student logout','POST','/api/auth/logout')
    req(student,'Auth','Logged-out student access denied','GET','/api/progress',401)

out=ROOT/'api_walkthrough_results.json'
summary=collections.Counter(r['status'] for r in REPORT)
out.write_text(json.dumps({'summary':dict(summary),'total':len(REPORT),'dataset':counts,'question_types':types,'results':REPORT},ensure_ascii=False,indent=2),encoding='utf-8')
print('END SUMMARY',dict(summary),'TOTAL',len(REPORT),'DATA',counts,'QUIZ TYPES',types,'REPORT',out)
