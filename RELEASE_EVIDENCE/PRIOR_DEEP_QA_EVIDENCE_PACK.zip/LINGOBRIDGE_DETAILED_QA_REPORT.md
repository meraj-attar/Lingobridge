# LingoBridge — Detailed Functional and Manual-Test Readiness Report

**Audit date:** 30 October 2026 project snapshot; executed in the current isolated environment. **Target:** the user-uploaded `LingoBridge_Enhanced_Offline_TTS_QA_2026-10-30.zip` (unchanged).

## Important distinction

**This audit was NOT a full manual browser click-through.** React dependencies (`vite`, `vitest`, `@playwright/test`) were not installed, an offline `npm install` failed with `ENOTCACHED`, and therefore the application cannot be rendered here. The test harness nevertheless made real authenticated HTTP requests to the existing FastAPI app using the unmodified project source, with a disposable seeded SQLite database. Full keyboard/mouse, loading, pixel-layout, mobile viewports, dialog, animation and audible quality checks are **BLOCKED / NOT RUN**, never represented as passes.

## Executive result

- **513 real API/database integration assertions: 510 PASS, 3 FAIL.** These are recorded in the JSON test evidence and scripts, not fabricated UI interactions.
- **Backend pytest:** 47 PASS, 0 FAIL (`backend_pytest.log`).
- **Node built-in tests:** 8 PASS, 0 FAIL (`node_native.log`).
- **Vitest suite and React/Vite production build:** BLOCKED; missing frontend dependencies.
- **Static frontend inventory:** 62 source files, 21 routed pages, 265 interactive JSX source elements; zero JSX parser errors. Inventory is a source-level count, not rendered clickable instances.
- **Browser voice inventory:** headless Chromium returned zero `speechSynthesis` voices, which does not establish the voices on the user’s Windows machine.
- **Safety:** all created users and changes were made only in `/mnt/data/lingobridge_manual_qa/disposable_manual_test.db`. No user PostgreSQL server, production credentials or production migrations were touched.

## Reproduced failures

| ID | Severity | Reproduction | Actual | Expected | Code area |
|---|---|---|---|---|---|
| BUG-01 | HIGH (content integrity) | Create a 2-option MCQ then `DELETE /api/admin/manage/options/{wrong_option_id}` | 200; quiz retains only one option | 409 or editing complete MCQ atomically to preserve 2–8 options | `backend/app/main.py`, generic admin delete |
| BUG-02 | MEDIUM (content integrity) | Create an 8-option MCQ then `POST /api/admin/manage/options` with a ninth incorrect option | 201; quiz accepts 9 options | Reject >8 options with 400/409 | `backend/app/main.py`, generic admin option create |
| BUG-03 | MEDIUM (input validation) | `PATCH /api/admin/manage/lessons/{id}` with `video_url: "javascript:alert(1)"` | 200; invalid URL stored | Reject unsafe/non-YouTube URL (or empty string) | `backend/app/main.py`, lesson update |

BUG-03 is **not proof of executable XSS**: the existing `src/utils/youtube.js` player extracts an ID and renders a fixed youtube-nocookie domain. This finding concerns missing server-side validation and data integrity.

## Scope of completed functional workflows

1. **Guest and authentication:** catalogue, registration, duplicate/weak/common-password rejection, login, logout, token/CSRF requirement, account deactivation and reactivation, role separation.
2. **Language and course catalogue:** validated seeded 10 languages, all 60 A1–C2 course module listings, language detail, lesson/vocabulary/quiz availability and idempotent course enrollment.
3. **Student learning:** enrolled vs unenrolled lesson permissions, lesson start, lesson detail, no student answer-key exposure, bookmarks, progress, activity, XP and daily goal, profile preferences.
4. **MCQs and other exercises:** one correctly scored quiz for each of the 10 languages; MCQ, fill-blank, matching and sentence-arrangement answers; wrong-answer failure, retry, one-time ticket replay rejection, anti-XP-farming, no cross-user ticket reuse, incomplete/duplicate/invalid answers rejected.
5. **Flashcards:** mark known and revise, schedule update, invalid states rejected, review record protected against unsafe deletion.
6. **Admin management:** real KPI counts and analytics API, students/activate/deactivate, language, level, course, module, lesson, vocabulary, question and achievement CRUD on isolated records; delete archival guard; edit restrictions after quiz history.
7. **Audio:** all ten locale status endpoints, no-voice failures, invalid input checks, upload security, valid WAV decoding and download, invalid placeholder rejected. See the voice table below.

## Per-page browser manual test coverage

The following table lists **every application route**. UI **source was inspected** and a checklist of individual button/form/link controls was generated, but interactive browser test status is **BLOCKED** for every row.

| Route | Key manual testing target | Source controls | Backend / supporting evidence | Actual click status |
|---|---|---:|---|---|
| `/` | Home / landing — get started, language cards, sign-in routes and feature descriptions | 11 | Partially: catalogue links/API; landing navigation NOT CLICKED | **BLOCKED** |
| `*` | 404 page — return home, browse languages | 4 | NOT RUN: route navigation / 404 click tests need frontend | **BLOCKED** |
| `/forgot-password` | Account recovery — information-only page and return link | 1 | NOT IMPLEMENTED: no self-service recovery | **BLOCKED** |
| `/languages` | Browse ten languages — language cards, filter, route into course | 1 | PASS: 10 languages and 60 course card API queries | **BLOCKED** |
| `/login` | Sign in — email/password, show password, error messages, recovery link | 9 | PASS: registration/login/logout and CSRF, role checks | **BLOCKED** |
| `/register` | Register — validation, strength checklist, show password, create account | 8 | PASS: password policy / duplicate email validation | **BLOCKED** |
| `/course/:code` | Course — language hero, six CEFR tabs, enroll, lesson cards and Start actions | 4 | PASS: 60 courses across 10 languages and 6 levels | **BLOCKED** |
| `/dashboard` | Student dashboard — welcome, KPIs, progress, enroll, continue, flashcards, profile | 7 | PASS: progress/activity/enrollment/recommendation API | **BLOCKED** |
| `/flashcards` | Flashcards — reveal/hide, pronunciation, prev/next, remembered/review tomorrow | 9 | PASS: known/revise, scheduling and persistence APIs | **BLOCKED** |
| `/lesson/:id` | Lesson — vocabulary, grammar, example speech, bookmarks, quiz, previous/next | 14 | PASS: lesson fetch, read permissions, bookmarks and vocabulary APIs | **BLOCKED** |
| `/lesson/:id/quiz` | Quiz — MCQ options, question/option sound, previous/next, submit/retry/results | 2 | PASS: 10 full language quiz attempts + retry/scoring/session tests | **BLOCKED** |
| `/profile` | Profile — preferences, goal, stats, achievements, charts, saved lessons, history | 11 | PASS: profile save/validation, activity, XP, history | **BLOCKED** |
| `/admin` | Admin dashboard — KPI cards, charts, refresh, quick navigation | 15 | PASS: KPIs cross-checked against database; refresh click NOT RUN | **BLOCKED** |
| `/admin/audio` | Audio manager — 10 voice cards, refresh, editable phrase, test sound | 3 | PASS: 10 statuses/503 fallbacks, WAV upload; real speech not available | **BLOCKED** |
| `/admin/curriculum` | Course/module/level managers — create/edit/delete, table switches | 10 | PASS: levels/course/module CRUD API | **BLOCKED** |
| `/admin/languages` | Language manager — list, activation, create/edit/delete, confirmation | 13 | PASS: create/edit/delete/archive API; button clicks NOT RUN | **BLOCKED** |
| `/admin/lessons` | Lesson manager — list, search/filter, publish, preview, create/edit/delete | 22 | PASS: lesson CRUD, publish data access/relationship validation | **BLOCKED** |
| `/admin/quizzes` | Quiz manager — question cards, 4 question types, answer keys, create/edit/delete | 18 | FAIL: 2 MCQ invariant bypasses; other CRUD and scoring tests PASS | **BLOCKED** |
| `/admin/students` | Students — counts, search/filter, pagination, activate/deactivate, detail | 6 | PASS: access, name change, deactivate/reactivate, counts | **BLOCKED** |
| `/admin/videos` | Video manager — language filter, preview, edit URL, save/cancel | 6 | FAIL: backend accepts unsafe video URL; UI sanitization exists | **BLOCKED** |
| `/admin/vocabulary` | Vocabulary manager — filter, add/edit/delete, audio preview | 15 | PASS: add/edit/delete + reviewed-card protection API; live speech blocked | **BLOCKED** |

### Source-level interactive-control coverage

Every `button`, `Button`, `Link`, `a`, `form`, `input`, `select`, and `textarea` identified in the 62 JavaScript/JSX files has a checklist row in **`LINGOBRIDGE_BROWSER_CONTROL_CHECKLIST.csv`** with route, file, line number, label, handler/destination and an honest browser execution status. These 265 JSX nodes may render many more controls at runtime (e.g., one speaker button per vocabulary item or one Test button per language). They are **not 265 clicked passes**.

### Important manual scenarios to execute after frontend dependencies are installed

| Area | Specific expected interaction / acceptance criterion | Status |
|---|---|---|
| Home | Get Started, Explore Languages, featured language cards, and login routes navigate correctly; no stale video feature claims after lesson section removal | BLOCKED |
| Auth | Keyboard-only registration, show/hide password, strength animation/checklist, invalid form messages, duplicate signup, logout and session refresh | BLOCKED |
| Student dashboard | Each KPI card matches server, enrolled course card loads correct language, Continue Learning and flashcard buttons route to correct learner data | BLOCKED |
| Course | Switch A1/A2/B1/B2/C1/C2 tabs; enroll disabled/loading/success state; lesson cards and Start buttons navigate correctly | BLOCKED |
| Lesson | Vocabulary speaker for word and example sentence, grammar, bookmarks add/remove, previous/next lesson, quiz button and missing-recording alert | BLOCKED |
| Quiz | Every MCQ answer button, question and option speaker, previous/next, complete-answer requirement, timed quiz, submit/retry, pass/fail and explanation cards, keyboard and RTL Urdu | BLOCKED |
| Flashcards | Next/previous, reveal/hide answer, Remembered, Review Tomorrow, filter, due schedule and persistence after refresh | BLOCKED |
| Profile | Save target/native language, daily goal, charts, XP, badges, saved lesson removal and retake history | BLOCKED |
| Admin dashboard | Refresh, KPI cards, charts and navigation shortcuts with real changing counts | BLOCKED |
| Admin languages | Create/edit modal, enable/disable toggle, delete confirm/cancel, empty/error list, persistence | BLOCKED |
| Admin curriculum | Course/module/level tab switches, create/edit/delete validation, association filters and error cases | BLOCKED |
| Admin lessons | Filters/search, create/edit, published/draft toggle, preview, navigation and delete safeguard UX | BLOCKED |
| Admin vocabulary | Language/lesson filter, word add/edit/delete, speaker, invalid audio/voice state | BLOCKED |
| Admin quizzes | Create, edit, delete, correct radio, fill/matching/arrangement entry, option limits, timer and grading UI | BLOCKED |
| Admin videos | Language filter, video preview, valid/invalid YouTube link save, cancel; student video section remains removed | BLOCKED |
| Admin audio | Refresh voices, each of 10 test phrase inputs and Test Pronunciation buttons, loading and no-voice errors | BLOCKED |
| Admin students | Search, filters, pagination, activate/deactivate, details; responsive small screens | BLOCKED |
| Responsive/accessibility | 320/375/768/1024/1440 px viewports, menu toggles, modal focus and screen-reader accessible labels | BLOCKED |

## Audio — actual availability, not assumptions

All 606 seed vocabulary records have empty `audio_url`; all 192 lessons also have empty lesson `audio_url`. The backend has no configured Piper model and no eSpeak NG installation. Headless Chromium voice inventory is empty. Therefore **not a single language is verified to play newly synthesized words here**. The 4 bundled demo files for English/Spanish passed `ffprobe` audio-stream/duration checks, while 5 legacy 35-byte placeholders were rejected. File decodability does not prove correct pronunciation or frontend speaker behavior.

| Language | Local Piper | eSpeak NG | Chromium browser voice | TTS HTTP behavior | Human listening QA |
|---|---|---|---|---|---|
| English (en) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Hindi (hi) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Marathi (mr) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Gujarati (gu) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Bengali (bn) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Tamil (ta) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Telugu (te) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Kannada (kn) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Urdu (ur) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |
| Spanish (es) | Not configured | Not installed | Not available | 503 with clear no-voice message | NOT RUN |

## Additional source-review limitations

- Password reset is an information-only page; self-service recovery is **not implemented**. This is disclosed directly in the user-facing page.
- The admin quiz form shows a fixed set of four MCQ option inputs without an Add/Remove Option control. Backend supports 2–8 only through some endpoints; the UI cannot dynamically author all supported option counts.
- After removing the student lesson videos, the landing page still advertises embedded YouTube videos and “Study Curated Lessons & Videos”; copy is inconsistent with the intended student experience.
- Static review found icon-only controls including Login/Register show-password buttons and mobile admin sidebar toggle without an accessible `aria-label` (subject to a browser accessibility audit).
- The admin video management route remains intentionally present and the player converts recognized video IDs into the fixed youtube-nocookie embed origin.
- No live password-reset emails, deployed PostgreSQL database, production JWT configuration, cross-browser voice quality, media autoplay, or device-permission behavior were tested.
- No real mouse/keyboard click-through, visual screenshot comparison, chart rendering, mobile breakpoint layout or frontend navigation acceptance was performed; the frontend build cannot run until dependencies are installed.

## Reproduction and environment

- Isolated DB: seeded SQLite with 10 languages, 60 courses, 192 lessons, 606 vocabulary entries, 778 questions and 928 answers (before test-only changes).
- Backend: FastAPI `TestClient` against actual project `app.main:app`, with isolated environment and per-role cookie/CSRF sessions. Test code, detailed names, expected and actual HTTP responses are in `api_walkthrough_results.json`, `quiz_boundary_results.json`, `admin_crud_results.json`.
- `backend_pytest.log`: 47 passed. `node_native.log`: 8 passed. `npm_offline.log`: `ENOTCACHED`, thus no node_modules. `vite_build.log`: `vite: not found`.
- Original full project ZIP is **not modified** by this test report. The three confirmed defects are reported, **not fixed** in this audit.

## Recommended next action

Fix the two MCQ invariant bypasses before a major-project demonstration, reject unsafe video URLs on the backend, install/verify appropriate local TTS voices, then launch FastAPI + Vite with an isolated PostgreSQL backup/clone and run the 265-control browser checklist with dedicated temporary student/admin accounts. Do not send real production passwords or database secrets.
