import os,sys,json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ.update(DATABASE_URL='sqlite:///'+str(ROOT/'disposable_manual_test.db'),JWT_SECRET='qa_disposable_0123456789_very_long_key_0123456789',ENVIRONMENT='test',MEDIA_DIR=str(ROOT/'test_media'))
sys.path.insert(0,str(ROOT/'lingobridge/backend'))
from fastapi.testclient import TestClient
from app.main import app
OUT=[]
def step(name,response,expected,tag='Admin CRUD'):
 ok=response.status_code==expected
 OUT.append({'name':name,'area':tag,'status':'PASS' if ok else 'FAIL','detail':f'expected {expected}; got {response.status_code}; {response.text[:160] if not ok else ""}','kind':'API integration'})
 if not ok:print('FAIL',name,response.status_code,response.text[:220])
 try:return response.json()
 except:return {}
with TestClient(app,raise_server_exceptions=False) as c:
 a=step('Admin login',c.post('/api/auth/login',json={'email':'manual-admin@example.com','password':'ManualAdmin123!'}),200)
 c.headers['X-CSRF-Token']=a['csrf']
 p='/api/admin/manage/'
 newl=step('Create language',c.post(p+'languages',json={'name':'QA Language','native_name':'QA','code':'qz','description':'Disposable QA'}),201)
 lid=newl.get('id')
 if lid:
  step('Update language display name',c.patch(p+'languages/'+lid,json={'name':'QA Language Edited'}),200)
  newcourse=step('Create course',c.post(p+'courses',json={'language_id':lid,'level_id':'lvl-a1','title':'QA Course','description':'Disposable'}),201)
  cid=newcourse.get('id')
  if cid:
   step('Update course',c.patch(p+'courses/'+cid,json={'title':'QA Course Updated'}),200)
   mod=step('Create module',c.post(p+'modules',json={'course_id':cid,'title':'QA Unit','sort_order':1}),201)
   mid=mod.get('id')
   if mid:
    step('Update module',c.patch(p+'modules/'+mid,json={'title':'QA Unit Updated'}),200)
    lesson=step('Create structured lesson',c.post(p+'lessons',json={'module_id':mid,'language_id':lid,'level_id':'lvl-a1','title':'QA Lesson','lesson_order':1,'is_published':True}),201)
    ls=lesson.get('id')
    if ls:
     step('Update lesson',c.patch(p+'lessons/'+ls,json={'title':'QA Lesson Updated'}),200)
     step('Reject unsafe YouTube URL by backend',c.patch(p+'lessons/'+ls,json={'video_url':'javascript:alert(1)'}),400,'Video validation')
     step('Accept valid YouTube video URL',c.patch(p+'lessons/'+ls,json={'video_url':'https://www.youtube.com/watch?v=dQw4w9WgXcQ'}),200,'Video validation')
     step('Remove disposable lesson',c.delete(p+'lessons/'+ls),200)
    step('Remove disposable module',c.delete(p+'modules/'+mid),200)
   step('Remove disposable course',c.delete(p+'courses/'+cid),200)
  step('Remove disposable language',c.delete(p+'languages/'+lid),200)
 level=step('Create CEFR-like custom level',c.post(p+'levels',json={'code':'QA','name':'QA Draft Level','sort_order':500}),201)
 lvid=level.get('id')
 if lvid:
  step('Update level',c.patch(p+'levels/'+lvid,json={'name':'Updated QA Draft Level'}),200)
  step('Remove level',c.delete(p+'levels/'+lvid),200)
 badge=step('Create achievement',c.post(p+'achievements',json={'code':'qa_badge_temp','title':'QA Badge','description':'Disposable','threshold':9999}),201)
 if badge.get('code'):
  step('Update achievement',c.patch(p+'achievements/qa_badge_temp',json={'title':'QA Badge Edited'}),200)
  step('Remove achievement',c.delete(p+'achievements/qa_badge_temp'),200)

counts=dict(collections.Counter(x['status'] for x in OUT))
print('ADMIN CRUD',counts,len(OUT))
(ROOT/'admin_crud_results.json').write_text(json.dumps({'summary':counts,'results':OUT},indent=2),encoding='utf-8')
