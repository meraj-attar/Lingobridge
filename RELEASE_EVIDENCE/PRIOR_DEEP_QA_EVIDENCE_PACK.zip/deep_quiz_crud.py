"""Additional negative and boundary tests against only the disposable QA database."""
import os,sys,json,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['DATABASE_URL']='sqlite:///'+str(ROOT/'disposable_manual_test.db')
os.environ['JWT_SECRET']='qa_disposable_0123456789_very_long_key_0123456789'
os.environ['ENVIRONMENT']='test';os.environ['MEDIA_DIR']=str(ROOT/'test_media')
sys.path.insert(0,str(ROOT/'lingobridge/backend'))
from fastapi.testclient import TestClient
from app.main import app
from app.db import SessionLocal
from app import models as m
from sqlalchemy import select, func
RESULTS=[]
def t(name,r,status=200,where='Quiz boundaries'):
    ok=r.status_code==status
    RESULTS.append(dict(name=name,area=where,status='PASS' if ok else 'FAIL',detail=f'expected {status}; got {r.status_code}; {r.text[:150] if not ok else ""}',kind='API integration'))
    if not ok:print('FAIL',name, r.status_code,r.text[:180]);return r
    return r
with TestClient(app,raise_server_exceptions=False) as s,TestClient(app,raise_server_exceptions=False) as admin,TestClient(app,raise_server_exceptions=False) as other:
    x=t('Authenticate new student',s.post('/api/auth/register',json={'email':'boundary-learner@example.com','full_name':'Boundary Learner','password':'BoundaryStudent123!'}),201)
    s.headers['X-CSRF-Token']=x.json()['csrf']
    x=t('Authenticate second learner',other.post('/api/auth/register',json={'email':'boundary-other@example.com','full_name':'Boundary Other','password':'BoundaryOther123!'}),201)
    other.headers['X-CSRF-Token']=x.json()['csrf']
    x=t('Authenticate admin',admin.post('/api/auth/login',json={'email':'manual-admin@example.com','password':'ManualAdmin123!'}),200)
    admin.headers['X-CSRF-Token']=x.json()['csrf']
    t('Course enrollment',s.post('/api/courses/course-hi-a1/enroll'))
    t('Second user enrollment',other.post('/api/courses/course-hi-a1/enroll'))
    lesson='les-hi-1'
    public=t('Get MCQ to student without answer key',s.get('/api/lessons/'+lesson))
    qs=public.json()['quiz_questions']
    with SessionLocal() as d:
        answers=[];wrong=[]
        for q in qs:
            model=d.get(m.Question,q['id'])
            if model.question_type=='mcq':
                opts=list(d.scalars(select(m.Option).where(m.Option.question_id==model.id)))
                answers.append({'question_id':model.id,'option_id':next(o.id for o in opts if o.is_correct)})
                wrong.append({'question_id':model.id,'option_id':next((o.id for o in opts if not o.is_correct),opts[0].id)})
            elif model.question_type=='matching':
                answers.append({'question_id':model.id,'text':'|'.join(f'{a}:{b}' for a,b in model.meta.get('pairs',[]))})
                wrong.append({'question_id':model.id,'text':'1:wrong|2:wrong'})
            else:
                answers.append({'question_id':model.id,'text':model.answer_text})
                wrong.append({'question_id':model.id,'text':'__incorrect__'})
    ticket=t('Issue unique quiz ticket',s.post(f'/api/lessons/{lesson}/quiz-session')).json()['attempt_token']
    t('Other learner cannot use first learner ticket',other.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':answers}),403)
    t('Reject unknown question ID',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':[{'question_id':'unknown','option_id':'bad'}]*len(answers)}),400)
    t('Reject duplicate answers',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':[answers[0]]*len(answers)}),400)
    t('Reject cross-question option',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':[{'question_id':answers[0]['question_id'],'option_id':'does-not-exist'}]+answers[1:]}),400)
    bad=t('Submit all deliberately wrong answers',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':wrong}))
    RESULTS.append(dict(area='Quiz boundaries',name='Wrong quiz does not pass',status='PASS' if not bad.json().get('passed') and bad.json().get('xp_earned')==0 else 'FAIL',detail=f"score={bad.json().get('score')} pct={bad.json().get('percentage')} xp={bad.json().get('xp_earned')}",kind='API integration'))
    t('Bad attempt session cannot be replayed',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':ticket,'answers':answers}),403)
    second=t('Create retry ticket',s.post(f'/api/lessons/{lesson}/quiz-session')).json()['attempt_token']
    good=t('Correct retry passes',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':second,'answers':answers}))
    RESULTS.append(dict(area='Quiz boundaries',name='First pass awards XP',status='PASS' if good.json().get('passed') and good.json().get('xp_earned')==10 else 'FAIL',detail=f"score={good.json().get('score')} xp={good.json().get('xp_earned')}",kind='API integration'))
    third=t('Create passed lesson retry ticket',s.post(f'/api/lessons/{lesson}/quiz-session')).json()['attempt_token']
    retry=t('Retake passed quiz',s.post(f'/api/lessons/{lesson}/submit',json={'attempt_token':third,'answers':answers}))
    RESULTS.append(dict(area='Quiz boundaries',name='No XP farming on retake',status='PASS' if retry.json().get('xp_earned')==0 else 'FAIL',detail=f"xp_earned={retry.json().get('xp_earned')}",kind='API integration'))
    t('Admin cannot edit question with historical learner answers',admin.patch(f'/api/admin/manage/questions/{answers[0]["question_id"]}',json={'question_text':'unsafe edit'}),409,where='Admin data integrity')
    t('Admin cannot delete attempted question',admin.delete(f'/api/admin/manage/questions/{answers[0]["question_id"]}'),409,where='Admin data integrity')
    t('Admin cannot delete attempted lesson',admin.delete(f'/api/admin/manage/lessons/{lesson}'),409,where='Admin data integrity')
    t('Admin cannot move populated module',admin.patch('/api/admin/manage/modules/module-hi-a1',json={'course_id':'course-en-a1'}),409,where='Admin data integrity')
    t('Admin cannot alter course language with lessons',admin.patch('/api/admin/manage/courses/course-hi-a1',json={'language_id':'lang-en'}),409,where='Admin data integrity')
    t('Admin cannot create invalid timer question',admin.post(f'/api/admin/lessons/{lesson}/questions',json={'question_text':'Bad timer?','time_limit_seconds':5,'options':[{'option_text':'true','is_correct':True},{'option_text':'false','is_correct':False}]}),400,where='Admin question validation')
    t('Admin cannot create 9-option MCQ through complete editor',admin.post(f'/api/admin/lessons/{lesson}/questions',json={'question_text':'Nine options','options':[{'option_text':str(i),'is_correct':i==0} for i in range(9)]}),400,where='Admin question validation')
    t('Admin cannot create matching without two pairs',admin.post(f'/api/admin/lessons/{lesson}/questions',json={'question_text':'matching question','question_type':'matching','meta':{'pairs':[['a','b']]}}),400,where='Admin question validation')
    # test option POST bypass using draft question; a valid question should never grow beyond 8 options
    newq=t('Create eight-option draft MCQ',admin.post(f'/api/admin/lessons/{lesson}/questions',json={'question_text':'Eight options draft','options':[{'option_text':str(i),'is_correct':i==0} for i in range(8)]}),201,where='Admin question validation')
    if newq.status_code==201:
        qid=newq.json()['id']
        bypass=admin.post('/api/admin/manage/options',json={'question_id':qid,'option_text':'Unexpected ninth option','is_correct':False})
        t('Prevent ninth option through generic admin endpoint',bypass,409,where='Admin question validation')
        # Remove new draft if possible; do not leave it exposed to demo users in QA DB
        t('Clean up disposable draft question',admin.delete(f'/api/admin/manage/questions/{qid}'),200,where='Admin question validation')
    # ensure admin stats are grounded in actual database counts
    stats=t('Get real admin KPI counters',admin.get('/api/admin/stats'),200,where='Admin analytics').json()
    with SessionLocal() as d:
        students=d.scalar(select(func.count()).select_from(m.User).where(m.User.role=='student'))
        authored=d.scalar(select(func.count()).select_from(m.Lesson).where(m.Lesson.is_published==True))
        actual=d.scalar(select(func.count()).select_from(m.QuizAttempt))
        RESULTS.extend([
          dict(area='Admin analytics',name='Student KPI matches database',status='PASS' if stats['total_students']==students else 'FAIL',detail=f"API={stats['total_students']} db={students}",kind='API integration'),
          dict(area='Admin analytics',name='Published lesson KPI matches database',status='PASS' if stats['total_lessons']==authored else 'FAIL',detail=f"API={stats['total_lessons']} db={authored}",kind='API integration'),
          dict(area='Admin analytics',name='Quiz attempts KPI matches database',status='PASS' if stats['total_attempts']==actual else 'FAIL',detail=f"API={stats['total_attempts']} db={actual}",kind='API integration')
        ])

counts=dict(collections.Counter(x['status'] for x in RESULTS));print('ADDITIONAL',counts,len(RESULTS))
(ROOT/'quiz_boundary_results.json').write_text(json.dumps({'summary':counts,'results':RESULTS},ensure_ascii=False,indent=2))
